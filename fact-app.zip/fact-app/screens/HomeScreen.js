import React, {Component} from 'react';
import{
  Text, 
  View, 
  StyleSheet,
  TouchableOpacity,
  Header,
  Image,
} from 'react-native';

import AppHeader from '../components/AppHeader';

render() {
  return(
    <View>
    <AppHeader />
    <View>
    <View style={Styles.buttonContainer}>
    <TouchableOpacity
    style={styles.buttonContainer}>
    OnPress={() => this.props.navigation.navigate
    ('Science')}>
          <Text style={{fontSize:20, color:'maroon'}}>ScienceFacts</Text>
    </TouchableOpacity>

          <TouchableOpacity
    style={styles.buttonContainer}>
    OnPress={() => this.props.navigation.navigate
    ('Math')}>
    <Text style={{fontSize:20, color:'maroon'}}>MathFacts</Text>
    </TouchableOpacity>

        <TouchableOpacity
    style={styles.buttonContainer}>
    OnPress={() => this.props.navigation.navigate
    ('Nature')}>
    <Text style={{fontSize:20, color:'maroon'}}>NatureFacts</Text>
    </TouchableOpacity>

    <TouchableOpacity
    style={styles.buttonContainer}>
    OnPress={() => this.props.navigation.navigate
    ('Funny')}>
    <Text style={{fontSize:20, color:'maroon'}}>FunnyFacts</Text>
    </TouchableOpacity>

    </View>
    <View style={styles.ratingContainer}>
    <Text style={{fontSize:22, textAlign:'Center',
    <TouchableOpacity>
    <Image
    style={{width:50,height:50,marginLeft:5}}
    source={require('../assets/thumbs-up-hand-symbol.png')}
   />
   </TouchableOpactiy>
    <TouchableOpacity>
    <Image
    style={{
      width:50,
      height:40,
      marginTop:-35
      marginLeft:100;
    }}
    source={require('../assets/thumbs-down-silhouette.png')}
    />
    </TouchableOpacity>
  </View>
  </View>
  </View>
   );}
    }

  const styles = StyleSheet.create({
    buttonsContainer: {
      alignSelf: 'Center',
      marginTOp:50,
    },
    buttons:{
      alignItems: 'center',
      justifyContent:'center',
      borderWidth: 2,
      borderRadius: 15,
      backgroundColor:"pink
      margin:10
      width:200
      height:50"
    },
    ratingContainer: {
      alignSelf:'center',
      marginTop: 50,
    },
    
  });
   
